#!/usr/bin/env python3
"""
rack_expand.py -- SR-JV80 expansion boards for LarkOS's RACK engine.

    python3 rack_expand.py <ROM folder> <output folder> [--levels <folder>] [board ...]

The ROM folder is the one rack_convert.py reads, with the boards beside the
instrument's own ROMs as SR-JV80-NN*.bin. With no board numbers, every board
found is converted, into one tree laid out as the card is:

    <output>/Samples/RACK/XNN/001 Wave Name.wav            every wave on board NN
    <output>/Patches/RACK/NN Title/NN.001 Patch Name.patch every patch that fits
    <output>/Oversize/NN Title/...                         patches that do not
    <output>/lists/NN.csv                                  what test/audit_patches reads

To use the boards, copy Samples and Patches into /System/Synths on the card,
merging with what is there -- or only the XNN and "NN Title" folders of the
boards wanted. Each board is a folder in the Tracker's patch browser, which
shows at most 256 entries in any one folder; no board has more. A board's
patches also use the instrument's own waves, so rack_convert.py's output has
to be on the card too.

"Fits" is about memory. The Tracker loads a patch's samples into a pool of
4 MB, and the boards were made to show off long multisamples: a patch whose
four waves come to more than that cannot load whole. Those are written to
Oversize instead, so that nothing in Patches fails on the instrument.

A board is laid out like the instrument's own ROMs (see rack_convert.py) with
a header that says where things are: the wave count at 0x62 and patch count at
0x66, and the addresses of the sample records at 0x80, the wave records at
0x84 and the patches at 0x8C. A tone names its wave by group and number;
group 1 is the board.

--levels names a folder of NN.csv files written by test/audit_patches, which
set each patch's Volume so they all sit at one level. `make rack-expansions`
runs the two passes.
"""

import os
import re
import struct
import sys

import numpy as np

import rack_convert as rc

POOL_BYTES = 4 * 1024 * 1024
FIT_BYTES = int(POOL_BYTES * 0.95)


class Board:
    """One expansion ROM, with the same face rc.build() expects of the
    instrument's own."""

    def __init__(self, path):
        self.wave = rc.unscramble(open(path, "rb").read())
        d = self.wave
        be16 = lambda o: (int(d[o]) << 8) | int(d[o + 1])
        be32 = lambda o: (be16(o) << 16) | be16(o + 2)
        self.ident = d[0x20:0x30].tobytes().split(b"\0")[0].decode("ascii", "replace").strip()
        self.n_samples, self.n_waves, self.n_patches = be16(0x60), be16(0x62), be16(0x66)
        self.sample_at, self.wave_at, self.patch_at = be32(0x80), be32(0x84), be32(0x8C)
        size = len(d)
        ok = (0 < self.n_waves < 1024 and 0 < self.n_samples < 4096 and self.n_patches < 1024 and
              self.wave_at + self.n_waves * 60 <= size and
              self.sample_at + self.n_samples * 18 <= size and
              self.patch_at + self.n_patches * rc.PATCH_SIZE <= size)
        if not ok:
            raise ValueError("header does not describe a board")

    def waves(self):
        out = []
        for i in range(self.n_waves):
            r = self.wave[self.wave_at + i * 60: self.wave_at + (i + 1) * 60].tobytes()
            zones = []
            for k in range(16):
                idx = struct.unpack(">H", r[28 + 2 * k: 30 + 2 * k])[0]
                if idx != 0xFFFF and idx < self.n_samples:
                    zones.append((r[12 + k], idx))
            out.append((r[:12].decode("ascii", "replace").strip(), zones))
        return out

    def sample(self, i):
        r = self.wave[self.sample_at + i * 18: self.sample_at + (i + 1) * 18].tobytes()
        b24 = lambda o: (r[o] << 16) | (r[o + 1] << 8) | r[o + 2]
        return dict(level=r[0], start=b24(1), loop=b24(4), end=b24(7), mode=r[12],
                    root=r[13], tune=((r[14] << 8) | r[15]) - 1024)

    def decode(self, start, end):
        end = min(end, len(self.wave) - 1)
        a = np.arange(start, end + 1, dtype=np.int64)
        s = self.wave[a].astype(np.int8).astype(np.int64)
        nb = self.wave[(a & ~0xFFFFF) | ((a & 0xFFFFF) >> 5)]
        nib = np.where((a >> 4) & 1, (nb >> 4) & 15, nb & 15).astype(np.int64)
        return np.cumsum(s << nib)

    def patch(self, i):
        return self.wave[self.patch_at + i * rc.PATCH_SIZE:
                         self.patch_at + (i + 1) * rc.PATCH_SIZE].tobytes()


def convert(path, number, title, internal, out_root, volumes):
    board = Board(path)
    tag = "X%02d" % number
    samples = os.path.join(out_root, "Samples", "RACK", tag)
    patches = os.path.join(out_root, "Patches", "RACK", "%02d %s" % (number, title))
    oversize = os.path.join(out_root, "Oversize", "%02d %s" % (number, title))
    os.makedirs(os.path.join(out_root, "lists"), exist_ok=True)
    os.makedirs(samples, exist_ok=True)
    os.makedirs(patches, exist_ok=True)

    waves = board.waves()
    sizes = {}
    files = []
    total = 0
    for n, (name, zones) in enumerate(waves):
        fn = rc.wave_file(n, name)
        files.append(fn if zones else None)
        if not zones:
            continue
        data = rc.build(board, zones)
        rc.write_wav(os.path.join(samples, fn), data)
        sizes["RACK/%s/%s" % (tag, fn)] = len(data) * 2
        total += len(data) * 2

    def resolve(group, num):
        if group == 0 and num < rc.N_WAVES:
            p = "RACK/" + rc.wave_file(num, internal["names"][num])
            sizes.setdefault(p, internal["sizes"][num])
            return p
        if group == 1 and num < len(files) and files[num]:
            return "RACK/%s/%s" % (tag, files[num])
        return None

    rows = []
    fit = big = empty = 0
    largest = (0, "")
    for i in range(board.n_patches):
        name, values, paths = rc.translate(board.patch(i), None, resolve)
        if not any(paths):
            empty += 1
            continue
        fn = "%02d.%03d %s" % (number, i + 1, rc.safe(name))
        if volumes and fn in volumes:
            values[rc.C_VOLUME] = volumes[fn]
        need = sum(sizes[p] for p in set(paths) if p)
        largest = max(largest, (need, fn))
        if need > FIT_BYTES:
            os.makedirs(oversize, exist_ok=True)
            dest = oversize
            big += 1
        else:
            dest = patches
            fit += 1
        with open(os.path.join(dest, fn + ".patch"), "wb") as f:
            f.write(rc.patch_file(values, paths))
        rows.append(fn + "," + ",".join(p if p else "-" for p in paths) + "," +
                    ",".join("%.6g" % x for x in values))
    with open(os.path.join(out_root, "lists", "%02d.csv" % number), "w") as f:
        f.write("\n".join(rows) + "\n")
    print("%02d %-28s %-10s %3d waves %5.1f MB   %3d patches, %3d too big for the pool%s   largest %.1f MB"
          % (number, title, board.ident, sum(1 for x in files if x), total / 1048576.0, fit, big,
             (", %d with no wave RACK can play" % empty) if empty else "", largest[0] / 1048576.0))
    return total, fit, big


def main():
    args = sys.argv[1:]
    levels = None
    if "--levels" in args:
        k = args.index("--levels")
        levels = args[k + 1]
        del args[k:k + 2]
    if len(args) < 2:
        sys.exit(__doc__)
    rom_dir, out_root = args[0], args[1]
    want = set(int(x) for x in args[2:])

    roms = rc.Roms(rom_dir)
    internal = {"names": [], "sizes": []}
    for name, zones in roms.waves():
        internal["names"].append(name)
        n = rc.HEADER_WORDS
        for _, idx in zones:
            s = roms.sample(idx)
            n += s["end"] - s["start"] + 1
        internal["sizes"].append(n * 2)

    found = []
    for f in sorted(os.listdir(rom_dir)):
        m = re.match(r"(?i)SR-JV80-(\d+)\s+(.*?)(\s+-\s+CS.*)?\.bin$", f)
        if m and (not want or int(m.group(1)) in want):
            found.append((int(m.group(1)), rc.safe(m.group(2)), os.path.join(rom_dir, f)))
    if not found:
        sys.exit("no SR-JV80-NN*.bin boards in %s" % rom_dir)

    grand = [0, 0, 0]
    for number, title, path in found:
        volumes = None
        if levels and os.path.exists(os.path.join(levels, "%02d.csv" % number)):
            volumes = {}
            for line in open(os.path.join(levels, "%02d.csv" % number)):
                k, _, val = line.strip().rpartition(",")
                if k:
                    volumes[k] = float(val)
        try:
            t, a, b = convert(path, number, title, internal, out_root, volumes)
        except ValueError as e:
            print("%02d %s: skipped, %s" % (number, title, e))
            continue
        grand[0] += t
        grand[1] += a
        grand[2] += b
    print("\n%d boards: %.0f MB of waves, %d patches that fit, %d set aside as too big"
          % (len(found), grand[0] / 1048576.0, grand[1], grand[2]))


if __name__ == "__main__":
    main()
