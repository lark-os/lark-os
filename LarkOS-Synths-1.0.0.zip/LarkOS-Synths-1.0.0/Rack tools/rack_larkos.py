#!/usr/bin/env python3
"""Writes the eight LarkOS patches for Rack: bank L, beside I, A and B.

    rack_larkos.py <folder holding Samples/RACK and Patches/RACK> [levels.csv]

They are new patches, not conversions: each layers waves the converter has
already written to the card (rack_convert.py), so this needs the waves to be
there and no ROM. It writes

    Patches/RACK/L01 ... L08 .patch
    larkos.csv                       the same patches as a list, for the checks

A patch whose waves are not all on the card is skipped and named. The optional
levels file is `name,volume` lines from test/audit_patches, as for the
converter.

Two each of pads, leads, basses and keys. The factory banks are single
instruments done well. These are the other thing a four-tone rack module is
for: layers that are not any one instrument, staged with tone delays, velocity
ranges and the two LFOs.
"""
import os
import sys

from rack_convert import (C_GLIDE, C_LFO2AMP, C_LFO2FILTER, C_LFO2PITCH, C_LFO2RATE, C_LFOAMP,
                          C_LFODELAY, C_LFOFILTER, C_LFOPITCH, C_LFORATE, C_TONESEL, C_TUNE,
                          C_VEL, C_VOLUME, EDIT_BASE, EXT_BASE, F_AA, F_AD, F_AR, F_AS,
                          F_COARSE, F_CUTOFF, F_ENVAMT, F_FA, F_FD, F_FINE, F_FMODE, F_FR, F_FS,
                          F_KEYF, F_LEVEL, F_PAN, F_RESO, N_PARAMS, PER_TONE, PER_TONE_EXT,
                          X_DELAY, X_PDEPTH, X_PTIME, X_VELHI, X_VELLO, patch_file)

OFF, LP, BP, HP = 0, 1, 2, 3


def tone(wave, level=.8, pan=0.0, coarse=0, fine=0, mode=LP, cutoff=1.0, reso=0.0, env=0.0,
         keyf=.5, fenv=(.005, .5, .5, .5), aenv=(.003, 1.0, 1.0, .3), pitch=(0.0, .1),
         vel=(0, 127), delay=0.0):
    """One tone. Cutoff is 40 Hz * 2^(9x); env is in units of 7.4 octaves;
    the envelopes are attack, decay, sustain level, release, in seconds."""
    return dict(wave=wave, level=level, pan=pan, coarse=coarse, fine=fine, mode=mode,
                cutoff=cutoff, reso=reso, env=env, keyf=keyf, fenv=fenv, aenv=aenv,
                pitch=pitch, vel=vel, delay=delay)


def patch(name, tones, lfo1=(5.0, 0.0, 0.0, 0.0, 0.0), lfo2=(.5, 0.0, 0.0, 0.0), vel=.5,
          glide=0.0, volume=.7):
    """lfo1 is rate (Hz), delay (s), then depth to pitch, filter and level,
    each 0..1; lfo2 is rate and the three depths."""
    return dict(name=name, tones=tones, lfo1=lfo1, lfo2=lfo2, vel=vel, glide=glide,
                volume=volume)


PATCHES = [
    # ------------------------------------------------------------------ pads
    # A choir that arrives in three stages: the voices, a bell on the front
    # of them that is gone in a second, and strings an octave up that only
    # appear if the chord is held.
    patch("Glass Choir", [
        tone("043 Male Ooh", level=1, pan=-.25, cutoff=.78, keyf=.4,
             aenv=(.6, 2.0, .85, 2.2)),
        tone("051 Fanta Bell", level=.69, pan=.3, coarse=12, cutoff=.9,
             aenv=(.004, 1.4, 0.0, 1.2)),
        tone("047 JP Strings", level=.75, pan=.35, coarse=12, mode=HP, cutoff=.45,
             aenv=(1.8, 3.0, .9, 2.6), delay=.9),
        tone("045 VOX Noise", level=.38, pan=-.4, mode=BP, cutoff=.72, reso=.35,
             aenv=(.9, 2.0, .6, 1.8)),
    ], lfo1=(4.6, 1.2, .08, 0.0, 0.0), lfo2=(.18, 0.0, .25, 0.0), vel=.3, volume=0.89),
    # Metal played backwards under a soft pad, each layer starting later than
    # the last and the slow LFO turning the filters over.
    patch("Tin Sky", [
        tone("046 Soft Pad", level=1, cutoff=.62, reso=.2, env=.08, keyf=.4,
             fenv=(1.5, 3.0, .6, 2.0), aenv=(.9, 3.0, .9, 3.0)),
        tone("117 REV Tin Wave", level=.62, pan=-.5, mode=BP, cutoff=.7, reso=.4,
             aenv=(.3, 4.0, .4, 2.5), delay=.5),
        tone("083 Spectrum 1", level=.56, pan=.5, coarse=12, mode=HP, cutoff=.5,
             aenv=(2.2, 4.0, .7, 3.2), delay=1.1),
        tone("080 Wind Chimes", level=.38, pan=.2, mode=HP, cutoff=.6,
             aenv=(.02, 5.0, .2, 3.0), delay=1.8),
    ], lfo2=(.11, 0.0, .45, .1), vel=.2, volume=0.78),

    # ----------------------------------------------------------------- leads
    # A saw with a blown bottle for its attack and breath along its length.
    patch("Bottle Saw", [
        tone("066 Synth Saw 1", level=1, cutoff=.66, reso=.3, env=.14, keyf=.7,
             fenv=(.01, .5, .5, .3), aenv=(.008, 1.0, .9, .25)),
        tone("035 Bottle", level=.88, pan=-.15, cutoff=.85,
             aenv=(.004, .5, .25, .2)),
        tone("034 Blow Pipe", level=.56, pan=.2, mode=HP, cutoff=.5,
             aenv=(.05, 1.0, .7, .25)),
    ], lfo1=(5.4, .5, .22, 0.0, 0.0), vel=.5, glide=.06, volume=0.83),
    # A plain lead, and behind it a feedback note that swells in an octave up
    # if the key is held long enough.
    patch("Held Feedback", [
        tone("065 Lead Wave", level=1, cutoff=.72, reso=.25, env=.1, keyf=.7,
             fenv=(.005, .4, .6, .3), aenv=(.005, 1.0, .9, .22)),
        tone("015 Stratus", level=.69, pan=-.2, cutoff=.8,
             aenv=(.006, 1.5, .7, .25)),
        tone("078 Feedbackwave", level=.75, pan=.25, coarse=12, cutoff=.8,
             aenv=(1.2, 2.0, 1.0, .5), delay=.55),
    ], lfo1=(5.8, .7, .28, 0.0, 0.0), vel=.5, glide=.04, volume=0.9),

    # ---------------------------------------------------------------- basses
    # A sine an octave down with a log drum struck on the front of it.
    patch("Log Sub", [
        tone("073 Sine", level=1, coarse=-12, mode=OFF,
             aenv=(.004, 1.2, .75, .18)),
        tone("057 Log Drum", level=.94, cutoff=.7, env=.15, keyf=.3,
             fenv=(.002, .2, 0.0, .2), aenv=(.002, .5, 0.0, .2)),
        tone("021 Fretless 1", level=.5, cutoff=.5, keyf=.3,
             aenv=(.01, 1.5, .5, .2)),
    ], vel=.6, volume=0.85),
    # A slapped string, a clavinet an octave below it and a pulse that the
    # filter snaps shut: all pluck.
    patch("Clav Slap", [
        tone("023 Slap Bass 1", level=1, cutoff=.85,
             aenv=(.002, .9, .2, .12)),
        tone("006 Clav 1", level=.69, pan=.15, coarse=-12, cutoff=.75,
             aenv=(.002, .6, .1, .12)),
        tone("070 Synth Pulse1", level=.69, pan=-.15, coarse=-12, cutoff=.34, reso=.45,
             env=.5, keyf=.3, fenv=(.002, .18, .1, .15), aenv=(.002, .8, .4, .12)),
    ], vel=.7, volume=1),

    # ------------------------------------------------------------------ keys
    # An electric piano and a vibraphone together under a slow tremolo, with
    # guitar harmonics that only speak when a key is hit hard.
    patch("Tines and Bars", [
        tone("002 SA Rhodes 1", level=1, pan=-.2, cutoff=.8,
             aenv=(.003, 3.0, 0.0, .5)),
        tone("055 Vibes", level=.75, pan=.25, cutoff=.85,
             aenv=(.003, 3.5, 0.0, .9)),
        tone("012 GTR HARM", level=.75, pan=.1, coarse=12,
             aenv=(.003, 2.0, 0.0, .8), vel=(100, 127)),
    ], lfo1=(4.4, 0.0, 0.0, 0.0, .3), vel=.8, volume=0.84),
    # Wood and gut: a marimba with a pizzicato section and a nylon string
    # inside each note, all of them short.
    patch("Wood and Gut", [
        tone("056 Marimba Wave", level=1, cutoff=.8,
             aenv=(.002, 1.1, 0.0, .5)),
        tone("040 Pizz", level=.81, pan=-.3, cutoff=.85,
             aenv=(.002, .7, 0.0, .3)),
        tone("010 Nylon GTR", level=.62, pan=.3, cutoff=.75,
             aenv=(.002, 1.6, 0.0, .5)),
        tone("060 Steel Drums", level=.38, pan=.1, coarse=12, mode=HP, cutoff=.5,
             aenv=(.002, .9, 0.0, .4), vel=(90, 127)),
    ], vel=.8, volume=0.85),
]


def values_of(p):
    v = [0.0] * N_PARAMS
    paths = [""] * 4
    for t in range(4):
        b = t * PER_TONE
        x = EXT_BASE + t * PER_TONE_EXT
        # A tone that is off: silent, everything else neutral, as the
        # converter leaves it.
        v[b + F_FMODE], v[b + F_CUTOFF], v[b + F_KEYF] = 1, 1.0, 0.5
        v[b + F_FA], v[b + F_FD], v[b + F_FS], v[b + F_FR] = 0.005, 0.5, 0.5, 0.5
        v[b + F_AA], v[b + F_AD], v[b + F_AS], v[b + F_AR] = 0.003, 1.0, 1.0, 0.3
        v[x + X_PTIME], v[x + X_VELHI] = 0.1, 127.0
        if t >= len(p["tones"]):
            continue
        tn = p["tones"][t]
        paths[t] = "RACK/" + tn["wave"] + ".wav"
        v[b + F_LEVEL], v[b + F_PAN] = tn["level"], tn["pan"]
        v[b + F_COARSE], v[b + F_FINE] = float(tn["coarse"]), float(tn["fine"])
        v[b + F_FMODE], v[b + F_CUTOFF], v[b + F_RESO] = tn["mode"], tn["cutoff"], tn["reso"]
        v[b + F_ENVAMT], v[b + F_KEYF] = tn["env"], tn["keyf"]
        v[b + F_FA], v[b + F_FD], v[b + F_FS], v[b + F_FR] = tn["fenv"]
        v[b + F_AA], v[b + F_AD], v[b + F_AS], v[b + F_AR] = tn["aenv"]
        v[x + X_PDEPTH], v[x + X_PTIME] = tn["pitch"]
        v[x + X_VELLO], v[x + X_VELHI] = float(tn["vel"][0]), float(tn["vel"][1])
        v[x + X_DELAY] = tn["delay"]
    (v[C_LFORATE], v[C_LFODELAY], v[C_LFOPITCH], v[C_LFOFILTER], v[C_LFOAMP]) = p["lfo1"]
    (v[C_LFO2RATE], v[C_LFO2PITCH], v[C_LFO2FILTER], v[C_LFO2AMP]) = p["lfo2"]
    v[C_VEL], v[C_GLIDE], v[C_TUNE], v[C_VOLUME] = p["vel"], p["glide"], 0.0, p["volume"]
    # The editor opens on tone 1, and its edit values have to agree with it.
    v[C_TONESEL] = 0.0
    for k in range(PER_TONE):
        v[EDIT_BASE + k] = v[k]
    for k in range(PER_TONE_EXT):
        v[EDIT_BASE + PER_TONE + k] = v[EXT_BASE + k]
    return [float(a) for a in v], paths


def main():
    if len(sys.argv) not in (2, 3):
        sys.exit(__doc__)
    root = sys.argv[1]
    samples = os.path.join(root, "Samples")
    out_dir = os.path.join(root, "Patches", "RACK")
    volumes = {}
    if len(sys.argv) == 3:
        for line in open(sys.argv[2]):
            k, _, val = line.strip().rpartition(",")
            if k:
                volumes[k] = float(val)
    os.makedirs(out_dir, exist_ok=True)
    rows = []
    for i, p in enumerate(PATCHES):
        values, paths = values_of(p)
        missing = [q for q in paths if q and not os.path.isfile(os.path.join(samples, q))]
        fn = "L%02d %s" % (i + 1, p["name"])
        if missing:
            print("skipped %s: not on the card: %s" % (fn, ", ".join(missing)))
            continue
        if fn in volumes:
            values[C_VOLUME] = volumes[fn]
        with open(os.path.join(out_dir, fn + ".patch"), "wb") as f:
            f.write(patch_file(values, paths))
        rows.append(fn + "," + ",".join(q if q else "-" for q in paths) + "," +
                    ",".join("%.6g" % a for a in values))
    with open(os.path.join(root, "larkos.csv"), "w") as f:
        f.write("\n".join(rows) + "\n")
    print("%d patches in %s" % (len(rows), out_dir))


if __name__ == "__main__":
    main()
