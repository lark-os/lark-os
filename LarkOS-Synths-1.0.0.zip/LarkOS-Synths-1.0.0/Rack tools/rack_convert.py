#!/usr/bin/env python3
"""rack_convert.py -- turn a JV-880's ROMs into the WAV files RACK plays.

    python3 rack_convert.py <folder with the ROM .bin files> <output folder>

Needs jv880_rom2.bin, jv880_waverom1.bin and jv880_waverom2.bin, and numpy.
Writes, under the output folder, the two things the card needs:

    Samples/RACK/   one WAV per internal wave (129), 32 kHz mono 16-bit
                    -> copy to /System/Synths/Samples/RACK/
    Patches/RACK/   one Tracker patch per factory patch (192)
                    -> copy to /System/Synths/Patches/RACK/
 Nothing here is Roland's data or code:
it reads files you supply and the ROMs themselves never go on the card.

What is in the ROMs, as worked out from the data:

  * The wave ROMs are address- and bit-scrambled per megabyte.
  * rom2 starts with the wave directory: 4 header bytes, then 129 records of
    60 bytes -- a 12-character name, 16 upper key limits, 16 sample numbers.
  * At 0x1E40 are the sample records, 18 bytes each: level, then start, loop
    and end as 24-bit addresses, a loop mode, root key, and fine tune in
    1/1024ths of a semitone about 1024.
  * Audio is 8-bit deltas with a 4-bit exponent per 16 samples, the exponents
    packed into the first 1/32 of each megabyte. Decoding is a running sum of
    delta << exponent, 20 bits wide.
  * Loop mode 0 is a forward loop, 1 goes back and forth, 2 is a one-shot,
    4 to 6 are the reversed waves.

A RACK wave file carries all of a wave's key zones end to end, with a table at
the front -- written as the first 196 samples -- that says where each one is:

  word 0,1   'RA' 'CK'            word 2  version (1)      word 3  zone count
  then 16 zones of 12 words:
    key limit, root key, tune (1/1024 semitone), mode (0 loop, 1 back-and-
    forth, 2 one-shot), gain (4096 = unity), start hi/lo, length hi/lo,
    loop start hi/lo (relative to the zone), reserved.
  A 'hi/lo' pair is two 15-bit halves, so no word ever looks negative.
"""

import os
import struct
import sys

import numpy as np

AA = [2, 0, 3, 4, 1, 9, 13, 10, 18, 17, 6, 15, 11, 16, 8, 5, 12, 7, 14, 19]
DD = [2, 0, 4, 5, 7, 6, 3, 1]
N_WAVES = 129
SAMPLE_TABLE = 0x1E40
HEADER_WORDS = 4 + 16 * 12
PEAK = 30000.0


def unscramble(raw):
    src = np.frombuffer(raw, dtype=np.uint8)
    i = np.arange(len(src), dtype=np.uint32)
    addr = i & ~np.uint32(0xFFFFF)
    for j in range(20):
        addr |= ((i >> j) & 1) << AA[j]
    s = src[addr]
    out = np.zeros(len(src), dtype=np.uint8)
    for j in range(8):
        out |= ((s >> DD[j]) & 1) << j
    return out


class Roms:
    def __init__(self, folder):
        def rd(name):
            for f in os.listdir(folder):
                if f.lower() == name:
                    return open(os.path.join(folder, f), "rb").read()
            sys.exit("missing %s in %s" % (name, folder))
        self.rom2 = rd("jv880_rom2.bin")
        self.wave = np.concatenate([unscramble(rd("jv880_waverom1.bin")),
                                    unscramble(rd("jv880_waverom2.bin"))])
        if self.wave[32:38].tobytes() != b"INT100":
            sys.exit("the wave ROM did not descramble to what was expected")

    def waves(self):
        out = []
        for i in range(N_WAVES):
            r = self.rom2[4 + i * 60: 64 + i * 60]
            zones = []
            for k in range(16):
                idx = struct.unpack(">H", r[28 + 2 * k: 30 + 2 * k])[0]
                if idx != 0xFFFF:
                    zones.append((r[12 + k], idx))
            out.append((r[:12].decode("ascii").strip(), zones))
        return out

    def sample(self, i):
        r = self.rom2[SAMPLE_TABLE + i * 18: SAMPLE_TABLE + (i + 1) * 18]
        b24 = lambda o: (r[o] << 16) | (r[o + 1] << 8) | r[o + 2]
        return dict(level=r[0], start=b24(1), loop=b24(4), end=b24(7), mode=r[12],
                    root=r[13], tune=((r[14] << 8) | r[15]) - 1024)

    def decode(self, start, end):
        a = np.arange(start, end + 1, dtype=np.int64)
        s = self.wave[a].astype(np.int8).astype(np.int64)
        nb = self.wave[(a & ~0xFFFFF) | ((a & 0xFFFFF) >> 5)]
        nib = np.where((a >> 4) & 1, (nb >> 4) & 15, nb & 15).astype(np.int64)
        return np.cumsum(s << nib)


def pair(v):
    return [(v >> 15) & 0x7FFF, v & 0x7FFF]


def build(roms, zones):
    header = [0x5241, 0x434B, 1, len(zones)]
    body = []
    offset = HEADER_WORDS
    for key, idx in zones:
        s = roms.sample(idx)
        pcm = roms.decode(s["start"], s["end"]).astype(np.float64)
        loop = s["loop"] - s["start"]
        mode = s["mode"]
        if mode >= 4:                       # the reversed waves: turn them round here
            pcm = pcm[::-1]
            mode, loop = 2, 0
        elif mode > 2:
            mode = 2
        peak = float(np.abs(pcm).max()) or 1.0
        out = np.round(pcm * (PEAK / peak)).astype(np.int16)
        gain = (peak / 65536.0) / (PEAK / 32768.0) * (s["level"] / 127.0)
        header += [key, s["root"], int(np.clip(s["tune"], -32000, 32000)) & 0xFFFF, mode,
                   int(min(32767, round(gain * 4096)))]
        header += pair(offset) + pair(len(out)) + pair(max(0, min(loop, len(out) - 1))) + [0]
        body.append(out)
        offset += len(out)
    header += [0] * (HEADER_WORDS - len(header))
    hdr = np.array(header, dtype=np.uint16).astype(np.int16)
    return np.concatenate([hdr] + body)


def write_wav(path, data, rate=32000):
    raw = data.astype("<i2").tobytes()
    with open(path, "wb") as f:
        f.write(b"RIFF" + struct.pack("<I", 36 + len(raw)) + b"WAVEfmt " +
                struct.pack("<IHHIIHH", 16, 1, 1, rate, rate * 2, 2, 16) +
                b"data" + struct.pack("<I", len(raw)) + raw)


def safe(name):
    return "".join(c if (c.isalnum() or c in " -+'") else "_" for c in name).strip()


def wave_file(n, name):
    return "%03d %s.wav" % (n + 1, safe(name))


# ------------------------------------------------------------------ patches
#
# The instrument's own patches, turned into Tracker patch files for RACK. A
# patch record is 362 bytes: a 12-character name, 14 bytes of common settings,
# then four tones of 84 bytes. Three banks of 64 sit in rom2.
#
# RACK is not the original and does not have all of its parameters, so this is
# a translation and not a copy. What carries over: which wave each tone plays,
# its level, pan and tuning, its filter type, cutoff, resonance and key follow,
# both envelopes, both LFOs, velocity response and velocity ranges, tone delay,
# portamento, and the pitch envelope where it is the usual kind -- a note that
# starts off pitch and settles. What does not: FXM, the modulation matrix, the
# delay modes other than the plain one, pitch envelopes that do anything more
# elaborate, and the chorus and reverb, which the Tracker has its own of. The envelope times, the cutoff scale, resonance, key follow, level law, LFO
# rates and depths and the velocity response are measured (see below).

BANKS = [("I", 0x8CE0), ("A", 0x10CE0), ("B", 0x18CE0)]
PATCH_SIZE = 362
TONE_SIZE = 84
KEYFOLLOW = [-100, -70, -50, -30, -10, 0, 10, 20, 30, 40, 50, 70, 100, 120, 150, 200]

PER_TONE = 17
(F_LEVEL, F_PAN, F_COARSE, F_FINE, F_FMODE, F_CUTOFF, F_RESO, F_ENVAMT, F_KEYF, F_FA, F_FD, F_FS,
 F_FR, F_AA, F_AD, F_AS, F_AR) = range(PER_TONE)
(C_LFORATE, C_LFODELAY, C_LFOPITCH, C_LFOFILTER, C_LFOAMP, C_VEL, C_GLIDE, C_TUNE,
 C_VOLUME) = range(4 * PER_TONE, 4 * PER_TONE + 9)
# The parameters added after the first seventy-seven, in the plugin's order:
# five more per tone, the second LFO, the tone selector, and the edit copies.
EXT_BASE = 4 * PER_TONE + 9
PER_TONE_EXT = 5
X_PDEPTH, X_PTIME, X_VELLO, X_VELHI, X_DELAY = range(PER_TONE_EXT)
C_LFO2RATE, C_LFO2PITCH, C_LFO2FILTER, C_LFO2AMP = range(EXT_BASE + 4 * PER_TONE_EXT,
                                                         EXT_BASE + 4 * PER_TONE_EXT + 4)
C_TONESEL = C_LFO2AMP + 1
EDIT_BASE = C_TONESEL + 1
N_PARAMS = EDIT_BASE + PER_TONE + PER_TONE_EXT
TYPE_ID = 14                      # --type-id-play-tracker in the Makefile


def s8(v):
    return v - 256 if v > 127 else v


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


# ---- the original's curves, measured.
#
# These tables were taken off the instrument's own firmware running in the
# VirtualJV emulator: one tone, one parameter moved at a time, the output
# measured. Envelope times are the length of a segment; the filter figures are
# the -3 dB point of white noise through the low-pass at middle C with key
# follow off. Nothing of the emulator is in RACK or in this script -- only the
# numbers it gave.

def table(points, v, log=False):
    xs = [p[0] for p in points]
    ys = [np.log(p[1]) if log else p[1] for p in points]
    y = float(np.interp(v, xs, ys))
    return float(np.exp(y)) if log else y


TIME = [(0, 0.002), (1, 0.012), (2, 0.022), (5, 0.036), (10, 0.066), (20, 0.166), (30, 0.29),
        (40, 0.512), (50, 0.855), (60, 1.39), (70, 2.24), (80, 3.56), (90, 5.64), (100, 8.87),
        (110, 13.95), (120, 22.3), (127, 30.9)]
CUTOFF = [(0, 60), (2, 141), (4, 242), (6, 336), (8, 430), (10, 539), (15, 781), (20, 1031),
          (30, 1562), (40, 2180), (50, 3000), (60, 4234), (70, 5977), (75, 7391), (80, 10164),
          (85, 14000), (90, 19000), (127, 20000)]
LEVEL_DB = [(0, -90.0), (8, -48.0), (16, -36.0), (32, -24.6), (64, -14.9), (96, -7.0), (127, 0.0)]
LFO_RATE = [(0, 0.16), (20, 0.214), (40, 0.557), (60, 1.198), (80, 2.563), (90, 3.754),
            (100, 5.50), (110, 8.04), (120, 11.77), (127, 15.37)]
LFO_PITCH_CENTS = [(0, 0), (1, 1), (5, 8), (10, 24), (20, 78), (63, 710)]
LFO_FILTER_OCT = [(0, 0), (5, 0.33), (20, 0.75), (63, 2.3)]
ENV_OCT_PER_UNIT = 0.14      # filter envelope: octaves per unit of depth, at full level
KEYFOLLOW_SCALE = 1.1        # "100%" measures as 1.1 octaves per octave
DELAY_PER_UNIT = 0.016       # tone delay, seconds per unit
# RACK's decay and release are exponentials given as the time to settle. The
# original's are straight lines in its own level units, which through its
# level law come out close to a straight line in decibels: about 40 dB over
# the segment from full level. An exponential of 1.4 times the segment's
# length falls at that rate.
DECAY_SCALE = 1.4
# Velocity curves 1 to 4. For the filter: the share of the envelope's depth a
# note at velocity 100 loses at a sensitivity of 57. For the level: the
# exponent of the velocity-to-level power law per unit of sensitivity.
FILTER_VEL_CURVE = [0.39, 0.69, 0.95, 0.18]
AMP_VEL_CURVE = [0.079, 0.15, 0.20, 0.04]
# The first envelope time is shortened or stretched by velocity: by this much
# per step of its setting either side of the middle, for a note at 100.
T1_VEL_PER_STEP = 0.07


def seconds(v):
    """An envelope time, 0..127, as the seconds its segment lasts."""
    return table(TIME, clamp(v, 0, 127), log=True)


def gain(units):
    """A level, 0..127, as a gain."""
    return 10.0 ** (table(LEVEL_DB, clamp(units, 0.0, 127.0)) / 20.0)


def adsr(t1, l1, t2, l2, t3, l3, t4, level=False, t1vel=7):
    """Four times and three levels down to attack, decay, sustain, release and
    the peak the envelope reaches. The attack runs to whichever of the first
    two levels is the higher; everything after that is the decay.

    For the amplifier (level=True) the decay and release are RACK's curves and
    the times are scaled to suit. For the filter they are straight lines, as
    the original's are, and the times are the segments' own."""
    peak = max(l1, l2, 1)
    first = seconds(t1) * clamp(1.0 + (t1vel - 7) * T1_VEL_PER_STEP, 0.3, 1.6)
    if l2 <= l1 and seconds(t2) >= 4.0:
        # The second segment is so long that it is where the note lives: the
        # level it is heading for is the sustain, and what comes after it is
        # rarely reached.
        sustain = clamp(l2 / float(peak), 0.0, 1.0)
        decay = seconds(t2) * (DECAY_SCALE if level else 1.0)
        release = seconds(t4) * ((DECAY_SCALE + 0.9 * (1.0 - sustain)) if level else 1.0)
        return (clamp(first, 0.001, 8.0), clamp(decay, 0.005, 40.0), sustain,
                clamp(release, 0.005, 16.0), peak / 127.0)
    if l2 > l1:
        # A level envelope that climbs in two steps is mostly there after the
        # first if the first level is already loud; count only as much of the
        # second step as there is level left to gain.
        left = (1.0 - gain(l1) / gain(l2)) if level else (1.0 - l1 / float(l2))
        attack = first + seconds(t2) * left
        decay = seconds(t3)
    else:
        attack = first
        decay = seconds(t3) + (seconds(t2) if l2 < l1 else 0.0)
    sustain = clamp(l3 / float(peak), 0.0, 1.0)
    if level:
        decay *= DECAY_SCALE
        # A release from a low sustain is slower in decibels than one from the top.
        release = seconds(t4) * (DECAY_SCALE + 0.9 * (1.0 - sustain))
    else:
        release = seconds(t4)
    return (clamp(attack, 0.001, 8.0), clamp(decay, 0.005, 40.0), sustain,
            clamp(release, 0.005, 16.0), peak / 127.0)


def translate(rec, wave_names, resolve=None):
    """One 362-byte patch record -> (name, 77 parameter values, 4 sample paths)."""
    name = rec[:12].decode("ascii", "replace").strip()
    common = rec[12:26]
    v = [0.0] * N_PARAMS
    paths = [""] * 4
    vel = []
    lfo = None
    lfo2 = None
    for t in range(4):
        tn = rec[26 + t * TONE_SIZE: 26 + (t + 1) * TONE_SIZE]
        b = t * PER_TONE
        # defaults for a tone that is off: silent, everything else neutral
        v[b + F_FMODE], v[b + F_CUTOFF], v[b + F_KEYF] = 1, 1.0, 0.5
        v[b + F_FA], v[b + F_FD], v[b + F_FS], v[b + F_FR] = 0.005, 0.5, 0.5, 0.5
        v[b + F_AA], v[b + F_AD], v[b + F_AS], v[b + F_AR] = 0.003, 1.0, 1.0, 0.3
        x = EXT_BASE + t * PER_TONE_EXT
        v[x + X_PTIME], v[x + X_VELHI] = 0.1, 127.0
        # A tone's wave is a group and a number: group 0 is the instrument's
        # own set, 1 an expansion board's. `resolve` turns the pair into a
        # sample path, or nothing if this conversion has no such wave.
        if (tn[0] & 0x80) == 0:
            continue
        if resolve is not None:
            path = resolve(tn[0] & 3, tn[1])
        elif (tn[0] & 3) == 0 and tn[1] < N_WAVES:
            path = "RACK/" + wave_file(tn[1], wave_names[tn[1]])
        else:
            path = None
        if not path:
            continue
        paths[t] = path

        aa, ad, as_, ar, apeak = adsr(tn[74], tn[75], tn[76], tn[77], tn[78], tn[79], tn[80], level=True,
                                     t1vel=tn[73] & 15)
        # RACK's level is squared on the way in, so the root of the gain; the
        # sustain is a ratio of gains, not of the original's level units.
        top = tn[67] * apeak
        v[b + F_LEVEL] = clamp(np.sqrt(gain(top)), 0.0, 1.0)
        as_ = clamp(gain(top * as_) / max(gain(top), 1e-6), 0.0, 1.0)
        v[b + F_PAN] = 0.0 if tn[68] > 127 else clamp((tn[68] - 64) / 63.0, -1.0, 1.0)
        v[b + F_COARSE] = float(clamp(s8(tn[37]), -24, 24))
        v[b + F_FINE] = float(clamp(s8(tn[38]), -50, 50))
        v[b + F_AA], v[b + F_AD], v[b + F_AS], v[b + F_AR] = aa, ad, as_, ar

        mode = (tn[55] >> 3) & 3            # 0 off, 1 low-pass, 2 high-pass
        v[b + F_FMODE] = {0: 0, 1: 1, 2: 3}.get(mode, 1)
        # RACK's own cutoff scale is 40 Hz * 2^(9x).
        v[b + F_CUTOFF] = clamp(np.log2(table(CUTOFF, tn[52], log=True) / 40.0) / 9.0, 0.0, 1.0)
        # Resonance is a peak of up to 12 dB, or 24 with the "hard" bit set.
        # RACK's filter has Q = 1 / (2 - 1.9 r), and is flat at Q = 0.707.
        peak_db = (tn[53] & 127) / 127.0 * 12.0 * (2.0 if tn[53] & 128 else 1.0)
        q = 0.707 + (10.0 ** (peak_db / 20.0) - 1.0) * 1.1
        v[b + F_RESO] = clamp((2.0 - 1.0 / q) / 1.9, 0.0, 1.0)
        v[b + F_KEYF] = clamp(KEYFOLLOW[tn[54] & 15] / 100.0 * KEYFOLLOW_SCALE, -1.0, 2.2)
        fa, fd, fs, fr, fpeak = adsr(tn[59], tn[60], tn[61], tn[62], tn[63], tn[64], tn[65],
                                     t1vel=tn[57] & 15)
        # The envelope moves the cutoff by so many octaves per unit of depth.
        # Velocity scales that depth on the original; RACK has no such
        # control, so the depth is set for a note played fairly hard (100).
        # How much depends on the velocity curve the tone uses (measured).
        soft = 1.0 - clamp(s8(tn[56]), 0, 63) / 57.0 * FILTER_VEL_CURVE[tn[55] & 3]
        soft = clamp(soft, 0.0, 1.0)
        v[b + F_ENVAMT] = clamp(s8(tn[58]) * ENV_OCT_PER_UNIT * fpeak * soft / 7.4, -1.0, 1.0)
        v[b + F_FA], v[b + F_FD], v[b + F_FS], v[b + F_FR] = fa, fd, fs, fr

        # Velocity to level is a power law whose exponent is 0.079 per unit
        # of sensitivity; RACK's is three times its Velocity setting.
        # The tone's velocity curve steepens or flattens that.
        vel.append(clamp(s8(tn[72]) * AMP_VEL_CURVE[tn[71] & 3] / 3.0, 0.0, 1.0))

        # Pitch envelope: carried over only when it is "start away from pitch,
        # come home" -- a first level reached at once, the rest at zero.
        pdepth, pt1, pl1, pl2, pl3 = s8(tn[43]), tn[44], s8(tn[45]), s8(tn[47]), s8(tn[49])
        if pdepth and pl1 and pt1 <= 12 and abs(pl3) <= 4:
            v[x + X_PDEPTH] = clamp(pdepth * pl1 / 63.0, -12.0, 12.0)
            v[x + X_PTIME] = clamp(seconds(tn[46]) * DECAY_SCALE * (1.0 if abs(pl2) <= 4 else 2.0), 0.005, 4.0)
        lo, hi = tn[3] & 127, tn[4] & 127
        if 0 < hi and lo <= hi:
            v[x + X_VELLO], v[x + X_VELHI] = float(lo), float(hi)
        if 0 < tn[69] < 128:
            v[x + X_DELAY] = clamp(tn[69] * DELAY_PER_UNIT, 0.0, 4.0)
        d2 = (abs(s8(tn[34])), abs(s8(tn[35])), abs(s8(tn[36])))
        if lfo2 is None and any(d2):
            lfo2 = (tn[28], d2)
        depths = (abs(s8(tn[31])), abs(s8(tn[32])), abs(s8(tn[33])))
        if lfo is None and any(depths):
            lfo = (tn[24], tn[25], depths)

    v[C_LFORATE] = 5.0
    if lfo is not None:
        rate, delay, (dp, df, da) = lfo
        v[C_LFORATE] = clamp(table(LFO_RATE, rate, log=True), 0.02, 30.0)
        v[C_LFODELAY] = clamp(seconds(delay) if delay else 0.0, 0.0, 3.0)
        v[C_LFOPITCH] = clamp(table(LFO_PITCH_CENTS, min(dp, 63)) / 100.0, 0.0, 1.0)
        v[C_LFOFILTER] = clamp(table(LFO_FILTER_OCT, min(df, 63)) / 2.0, 0.0, 1.0)
        v[C_LFOAMP] = clamp(1.0 - 10.0 ** (-0.29 * min(da, 63) / 20.0), 0.0, 1.0)
    v[C_LFO2RATE] = 0.5
    if lfo2 is not None:
        rate2, (dp, df, da) = lfo2
        v[C_LFO2RATE] = clamp(table(LFO_RATE, rate2, log=True), 0.02, 30.0)
        v[C_LFO2PITCH] = clamp(table(LFO_PITCH_CENTS, min(dp, 63)) / 100.0, 0.0, 1.0)
        v[C_LFO2FILTER] = clamp(table(LFO_FILTER_OCT, min(df, 63)) / 2.0, 0.0, 1.0)
        v[C_LFO2AMP] = clamp(1.0 - 10.0 ** (-0.29 * min(da, 63) / 20.0), 0.0, 1.0)
    v[C_VEL] = float(np.mean(vel)) if vel else 0.5
    v[C_GLIDE] = clamp(seconds(common[13] & 127) * 0.5, 0.0, 2.0) if (common[12] & 0x40) else 0.0
    v[C_TUNE] = 0.0
    v[C_VOLUME] = clamp(0.8 * np.sqrt(common[9] / 127.0), 0.0, 1.0)
    # The editor opens on tone 1, so the edit parameters are tone 1's values.
    # They have to agree: on load an edit value is written through to the
    # selected tone, and a stale one would overwrite it.
    v[C_TONESEL] = 0.0
    for k in range(PER_TONE):
        v[EDIT_BASE + k] = v[k]
    for k in range(PER_TONE_EXT):
        v[EDIT_BASE + PER_TONE + k] = v[EXT_BASE + k]
    return name, [float(x) for x in v], paths


# ---- the Tracker's patch file: a protobuf message, written by hand so this
# script needs nothing but numpy. Field numbers are from Patch.proto.

def varint(n):
    n &= (1 << 64) - 1
    out = bytearray()
    while True:
        b = n & 0x7F
        n >>= 7
        out.append(b | (0x80 if n else 0))
        if not n:
            return bytes(out)


def field(num, wire, payload):
    return varint((num << 3) | wire) + payload


def message(num, body):
    return field(num, 2, varint(len(body)) + body)


def f32(num, value):
    return field(num, 5, struct.pack("<f", value))


MACROS = [
    ("Cutoff", True, [(t * PER_TONE + F_CUTOFF, 1.0) for t in range(4)]),
    ("Resonance", False, [(t * PER_TONE + F_RESO, 1.0) for t in range(4)]),
    ("Attack", True, [(t * PER_TONE + F_AA, 1.0) for t in range(4)]),
    ("Release", True, [(t * PER_TONE + F_AR, 1.0) for t in range(4)]),
    ("Balance", True, [(0 * PER_TONE + F_LEVEL, -0.5), (1 * PER_TONE + F_LEVEL, -0.5),
                       (2 * PER_TONE + F_LEVEL, 0.5), (3 * PER_TONE + F_LEVEL, 0.5)]),
    ("Vibrato", False, [(C_LFOPITCH, 1.0)]),
    ("", False, []),
    ("", False, []),
]


def patch_file(values, paths):
    out = field(1, 0, varint(TYPE_ID))
    for x in values:                                   # 6: repeated Param { float value = 1 }
        out += message(6, f32(1, x))
    for pth in paths:                                  # 7: Sample { string filePath = 1 }, always 4
        out += message(7, message(1, pth.encode("ascii")) if pth else b"")
    for name, bipolar, mods in MACROS:                 # 8: Macro, always 8, 6 modifiers each
        body = b""
        if name:
            body += message(1, name.encode("ascii"))
        if bipolar:
            body += field(2, 0, varint(1))
        if mods:
            body += field(3, 0, varint(len(mods)))
        for k in range(6):
            if k < len(mods):
                m = (field(1, 0, varint(mods[k][0])) if mods[k][0] else b"") + f32(2, mods[k][1])
            else:
                m = b""
            body += message(4, m)
        out += message(8, body)
    # 9: Sequencer { Config { ArpConfig { style = Random, octaveRange = 1 } } }, as the
    # firmware itself writes for a patch with nothing sequenced.
    arp = field(1, 0, varint(3)) + field(2, 0, varint(1))
    out += message(9, message(1, message(2, arp)))
    return out


def write_patches(roms, out_dir, csv_path, volumes=None):
    names = [n for n, _ in roms.waves()]
    os.makedirs(out_dir, exist_ok=True)
    rows = []
    count = 0
    for prefix, base in BANKS:
        for i in range(64):
            rec = roms.rom2[base + i * PATCH_SIZE: base + (i + 1) * PATCH_SIZE]
            name, values, paths = translate(rec, names)
            fn = "%s%02d %s" % (prefix, i + 1, safe(name))
            if volumes and fn in volumes:
                values[C_VOLUME] = volumes[fn]
            with open(os.path.join(out_dir, fn + ".patch"), "wb") as f:
                f.write(patch_file(values, paths))
            rows.append(fn + "," + ",".join(p if p else "-" for p in paths) + "," +
                        ",".join("%.6g" % x for x in values))
            count += 1
    with open(csv_path, "w") as f:
        f.write("\n".join(rows) + "\n")
    return count


def main():
    if len(sys.argv) not in (3, 4):
        sys.exit(__doc__)
    roms = Roms(sys.argv[1])
    out = sys.argv[2]
    samples = os.path.join(out, "Samples", "RACK")
    patches = os.path.join(out, "Patches", "RACK")
    os.makedirs(samples, exist_ok=True)

    volumes = None
    if len(sys.argv) == 4:           # a levels file from test/audit_patches: name,volume
        volumes = {}
        for line in open(sys.argv[3]):
            k, _, val = line.strip().rpartition(",")
            if k:
                volumes[k] = float(val)

    total = 0
    for n, (name, zones) in enumerate(roms.waves()):
        data = build(roms, zones)
        write_wav(os.path.join(samples, wave_file(n, name)), data)
        total += len(data) * 2
    print("%d waves, %.1f MB, in %s" % (N_WAVES, total / 1048576.0, samples))
    count = write_patches(roms, patches, os.path.join(out, "patches.csv"), volumes)
    print("%d patches in %s" % (count, patches))


if __name__ == "__main__":
    main()
