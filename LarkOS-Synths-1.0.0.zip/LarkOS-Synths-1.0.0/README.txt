LarkOS Synths
=============

Seven synth engines from LarkOS, as plugins for the Polyend Tracker Mini and
Tracker+. They also run on the beta builds of Polyend's own Tracker
Community Edition firmware, so you don't need LarkOS to use them.

  HEXA   six-voice wavetable synth, warm and drifting, with 40 wavetables
  JUNE   six-voice Juno-style polysynth with its chorus
  HAM    tonewheel organ: nine drawbars, percussion, scanner vibrato,
         key click and a rotary speaker
  SOLI   violin, viola, cello and double bass, bowed or plucked, modelled
         rather than sampled. (A new engine: until now SOLI was a
         string machine. See "Good to know".)
  X0X    808 and 909 drum kits, synthesised, chosen drum by drum
  ROAD   tine electric piano, modelled rather than sampled, with its
         preamp, stereo vibrato and suitcase cabinet
  RACK   four-tone sample-playback synth in the style of a 1990s rack
         module. It plays waves you make from your own Roland JV-880 ROMs
         (see "Rack" below) and comes with no waves or patches.

All seven are original DSP and free.


What you need
-------------

- A Tracker Mini (either edition) or a Tracker+.
- Firmware that loads synth plugins from System/Synths: LarkOS, or a
  Tracker Community Edition beta build from 22 November 2026 or later.
  Community Edition 1.0.0, the stable release, has no synth plugins, and
  neither has the original Polyend firmware.

If you run LarkOS, its card already has these. Copy them only to update a
plugin to a newer version.


Installing
----------

1. Turn the Tracker off and put its SD card in your computer.
2. In this download, "SD card" holds the files laid out as they go on the
   card. Copy them across:

     the seven .psyn files in SD card/System/Synths
         into System/Synths on the card
     the 40 .wav files in SD card/System/Synths/Samples/HEXA/Tables
         into System/Synths/Samples/HEXA/Tables on the card
         (make any of those folders that aren't there yet)

   On Windows you can instead copy the System folder onto the top level of
   the card: Windows merges it with the System folder there. A Mac's Finder
   would replace the card's whole System folder unless you hold Option while
   dragging and choose Merge, so on a Mac copy the files as above.
3. Put the card back and turn the Tracker on.
4. Choose one of the engines as an instrument's synth model. Hexa, June,
   Soli, Ham and Road have a Preset setting on their first page, and X0X a
   Kit setting.
   Rack's presets are patch files, loaded with Load (see below).


Rack
----

Rack plays the waves and patches of a Roland JV-880, converted from ROM files
of the instrument that you supply. Rack contains no Roland code and no sample
data, and none come with it.

To make them you need your three ROM files: jv880_rom2.bin,
jv880_waverom1.bin and jv880_waverom2.bin. Then use either

- the Rack card builder on the LarkOS site, which runs in your browser and
  sends nothing anywhere: https://lark-tracker.github.io/lark-os/
  It also evens out the patches' loudness, so it's the easier choice.
- or the scripts in "Rack tools", which need Python 3 and numpy
  (pip3 install numpy). Put the ROM files in one folder, then:

    python3 rack_convert.py <ROM folder> <output folder>
    python3 rack_larkos.py <output folder>

  The first writes 129 waves and the instrument's 192 patches (banks I, A and
  B), each at the level the instrument stores, so some sit louder than
  others. The second adds bank L, eight patches written for Rack from the
  same waves.

Either way, the result has a folder called RACK under Samples and another
under Patches. Copy the first into System/Synths/Samples on the card and the
second into System/Synths/Patches (make Patches if it isn't there).

On the Tracker, choose Rack as an instrument's model and open Load. Highlight
a patch to load it.

If you also own SR-JV80 expansion boards, put their ROMs (SR-JV80-NN*.bin) in
the same folder as the instrument's and run

    python3 rack_expand.py <ROM folder> <output folder>

Each board becomes its own folder of patches. A board's patches also use the
instrument's waves, so rack_convert.py's output needs to be on the card too.


Good to know
------------

- Hexa looks for its tables in System/Synths/Samples/HEXA/Tables. On LarkOS
  you can add up to two of your own: mono 16-bit WAVs of 2 to 64 frames of
  256 samples. They are listed after the 40 that ship. The Community Edition
  firmware can't list a folder for a plugin, so there Hexa finds its own 40
  tables by name and no others.
- Soli is one instrument at a time: choose Violin, Viola, Cello or Bass on
  its first page, and use a second Soli for a second instrument. On a track,
  a note that follows another without a gap is slurred (the finger moves and
  the bow keeps going); leave a gap, or turn Legato off, for a new bow
  stroke. Play switches between Bowed and Pizz, and is also the sixth macro,
  so a pattern can change it with a macro step.
- Soli used to be a string machine, and this Soli replaces it under the same
  name. A patch or project saved with the old one opens in the new one, but
  its settings mean nothing there: choose a preset and save it again.
- Road's notes ring for as long as the key is held, as on the instrument,
  and its Pedal setting keeps them ringing after the key is let go. Pedal is
  also Road's sixth macro, so a pattern can press and lift it with a macro
  step.
- A track plays one note at a time, so Road's Ring setting (Keys page) keeps
  the notes of the last few steps ringing under the new one, as a player's
  hand would: 3 steps to start with, Off, up to 6, or Hold. An OFF step lets
  go of all of them. A Chord FX step counts as one step; for chord parts,
  set Ring to Off.
- X0X's Key Layout setting is read by LarkOS's beta firmware. On any other
  firmware it's just a setting, and the kit plays the same.
- To remove an engine, delete its .psyn file from System/Synths.
- SHA256SUMS.txt lists a checksum for every file, to check a download.


Free, and as is
---------------

These plugins are free. Please share this download as it is, with this file
and the licence.

LarkOS is an independent project, not affiliated with or endorsed by Polyend.
Polyend, Tracker and Tracker Mini are Polyend's names, used here only to say
what these plugins run on. Roland, Juno, JV-880, 808 and 909 are Roland's
names, used only to describe a style; none of these plugins contains Roland
code or data. Rhodes is a trademark of its owner; Road is not affiliated with
it, and contains no samples of any instrument.

The plugins come as is, without warranty of any kind, and you install them at
your own risk. Custom firmware and plugins aren't covered by Polyend's
warranty, and Polyend doesn't support them, so please bring questions to
LarkOS rather than to Polyend: https://github.com/lark-tracker/lark-os

Soli's bow and string follow M. E. McIntyre, R. T. Schumacher and
J. Woodhouse, "On the oscillations of musical instruments", Journal of the
Acoustical Society of America 74 (1983), 1325-1345, doi:10.1121/1.390157,
and J. O. Smith, "Efficient simulation of the reed-bore and bow-string
mechanisms", Proc. ICMC 1986. Its bodies and string losses were measured
from the VSCO-2 Community Edition samples by Versilian Studios
(https://github.com/sgossner/VSCO-2-CE, CC0); none of the samples is in
Soli. No code from any of them is used.

Road's model follows the physics in A. Falaize and T. Helie, "Passive
simulation of the nonlinear port-Hamiltonian modeling of a Rhodes Piano",
Journal of Sound and Vibration 390 (2017), 289-309,
doi:10.1016/j.jsv.2016.11.008. Its numbers per key were
measured from Jeff Learman's jRhodes3d recordings of a 1977 Mark I Stage 73
(https://github.com/sfzinstruments/jlearman.jRhodes3d); none of the
recordings is in Road. No code from either is used.

Licence: LICENSE.txt, the Polyend Tracker Community Edition licence. Part 1,
the MIT licence, covers the SDK and these engines.
