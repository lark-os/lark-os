# LarkOS 1.0.0

The first stable release of LarkOS for the Polyend Tracker Mini and Mini AE.

## What it adds

- **Beads**: granular processing as a fourth send
- **Cassette**: tape across the whole song
- **A fourth master FX page**
- **DX7 cartridge banks** on the Plaits synth (bring your own banks)
- **Chords**: a chord palette that follows the project key, with a colour and
  a voicing for every chord, and notes that stay in the key
- **Nine more synths**: Soli, June, Hexa (40 wavetables, 48 presets), Ham,
  Rack, Road, X0X, Plaits and Rings. Chip, the plugin kit's example voice,
  is on the card too
- **Start-up safety**: a start that fails is noticed, and the Tracker starts
  safe or switches itself off and says why

The Field Guide in this download covers each of these from the playing side.

## Two lines of LarkOS

- **1.x.x, stable**: this release.
- **2.x.x, beta**: the same, plus features still being worked on. Not in
  this download.

Projects made on one open on the other.

## Known limits

- Tracks 1 and 2 are treated as drum tracks: on them the +1 / -1 keys move a
  note by semitone, not along the scale.
- Rack has no waves and Plaits no DX7 banks until you add your own.

LarkOS is community firmware. It is not made or supported by Polyend, and
running it is at your own risk.
