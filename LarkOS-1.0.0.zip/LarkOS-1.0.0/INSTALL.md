# Installing LarkOS 1.0.0 on a Polyend Tracker Mini or Mini AE

LarkOS is free community firmware for the Polyend Tracker Mini and Mini AE,
built from
Polyend's Tracker Community Edition sources. It is not made, tested or
supported by Polyend.

**Read this first.** You install and run it at your own risk. Community
firmware is not covered by Polyend's standard warranty. Back up your SD card
before you start. You can go back to Polyend's firmware at any time (see the
end of this page).

## What you need

- A Polyend Tracker Mini or Mini AE and its microSD card
- A computer that can read the card
- The stock firmware file for your Tracker from polyend.com, kept
  somewhere safe, so you can go back

## Install

1. **Back up the card.** Copy everything on it to your computer.
2. **Unzip** `LarkOS-1.0.0.zip`. Inside is a folder called `SD-card` with two
   folders in it: `Firmware` and `System`.
3. **Copy both onto the card, merging with what is there.** Do not replace
   the card's own `System` folder: add to it.
   - **Windows:** drag `Firmware` and `System` onto the card and choose to
     merge the folders.
   - **Mac:** Finder replaces folders by default, which would delete what is
     already in `System`. Use Terminal, with your card's name in place of
     `CARDNAME`:

     ```
     ditto ~/Downloads/LarkOS-1.0.0/SD-card /Volumes/CARDNAME
     ```
   - **Linux:** `cp -r LarkOS-1.0.0/SD-card/. /media/you/CARDNAME/`
4. **Eject** the card, put it back in the Tracker Mini and switch it on.
5. On the Tracker, open **Config > Firmware > Firmware update**, choose
   `TrackerMini_LarkOS_1.0.0.ptf` and confirm.
6. Wait while it installs and restarts. Do not switch it off. The start
   screen says LarkOS when it is done.

The synths in `System/Synths` appear in an instrument's Model list. The
Field Guide (`LarkOS-Field-Guide.pdf`) says what is new and how to play it.

## What is not in the download

Rack and Plaits are included, but not the wave data for Rack or DX7 banks for
Plaits: those are made from ROMs and cartridges that are not LarkOS's to give
away. Both work without them; the Field Guide says how to add your own.

## Going back to Polyend's firmware

Put Polyend's `.ptf` in the card's `Firmware` folder, open
**Config > Firmware > Firmware update**, choose it and confirm. Your projects
stay on the card.

## If the Tracker will not start

LarkOS looks after itself first: after two starts that do not finish it
starts with nothing loaded, and after three it switches itself off and
leaves a note in `LarkOS-crash.txt` on the card.

If it still will not start, use the Tracker's own emergency recovery, which
does not depend on the firmware:

1. On your computer, make Polyend's `.ptf` the **only** `.ptf` file in the
   card's `Firmware` folder. Move the LarkOS file out: recovery installs
   whichever file it finds there.
2. Put the card in the Tracker Mini and switch it on.
3. Press the recessed button next to the USB-C port with a paperclip. The
   Tracker installs the file from `Firmware`.

## Licence

LarkOS is free and may not be sold. See `LICENSE` and `NOTICE.md`. The six
Polyend synth engines are included unmodified under the licence beside them
in `System/Synths`.
